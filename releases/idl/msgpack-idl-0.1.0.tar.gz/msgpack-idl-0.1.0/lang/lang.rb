LANGDIR = File.dirname(__FILE__)

